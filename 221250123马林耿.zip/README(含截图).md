#### 一、项目内容

实现了要求文档所述所有功能（含附加要求）

#### 二、实验截图

（截图加载不出来可看图片文件夹qaq）

首先取消定时清屏。

##### 1. 输入与删除

正常输入（lg lgg[\t]lggg[\n]lg）。

![image-20240520221946930](https://raw.githubusercontent.com/mlger/Pict/main/newPath/image-20240520221946930.png)

删除两个字母：

![image-20240520222224164](https://raw.githubusercontent.com/mlger/Pict/main/newPath/image-20240520222224164.png)

再按一下删除

![image-20240520222239851](https://raw.githubusercontent.com/mlger/Pict/main/newPath/image-20240520222239851.png)

再删四个字母

![image-20240520222331989](https://raw.githubusercontent.com/mlger/Pict/main/newPath/image-20240520222331989.png)

再按一下

![image-20240520222350891](/home/lg/Documents/OS/OS-Lab/图片/5.png)

##### 2. 查找

输入串：lgg[空格\*4]lgg[\t]lgg[\n]lgg[\t]lgg[空格\*4]lgg

查找 lgg[空格\*4]lgg :

![image-20240520222735939](https://raw.githubusercontent.com/mlger/Pict/main/newPath/image-20240520222735939.png)

查找 lgg[\t]lgg ：

![image-20240520222805884](https://raw.githubusercontent.com/mlger/Pict/main/newPath/image-20240520222805884.png)

##### 3. undo & redo

输入串与上一步相同。删除三个字母：

![image-20240520223008870](https://raw.githubusercontent.com/mlger/Pict/main/newPath/image-20240520223008870.png)

恢复两个字母：

![image-20240520223043658](https://raw.githubusercontent.com/mlger/Pict/main/newPath/image-20240520223043658.png)

重做一步（删除一个字母）：

![image-20240520223055649](https://raw.githubusercontent.com/mlger/Pict/main/newPath/image-20240520223055649.png)

最后恢复清屏：

![image-20240520223134427](https://raw.githubusercontent.com/mlger/Pict/main/newPath/image-20240520223134427.png)
